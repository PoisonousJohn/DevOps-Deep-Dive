# Calculator Test Demo - Hard to Test
Branch with a code structure that is hard to test because of dependencies.
