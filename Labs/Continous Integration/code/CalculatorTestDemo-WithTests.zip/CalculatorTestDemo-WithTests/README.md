# Calculator Test Demo - With Tests
Branch with the same code as the [EasyToTest](https://github.com/GSIAzureCOE/CalculatorTestDemo/tree/EasyToTest) branch, but with tests added for most operations.
