# Calculator Test Demo - Easy to Test
Branch with a code structure that is easy to test because dependencies are handled through interfaces that can be replaced by other implementations (such as stubs or mocks).
